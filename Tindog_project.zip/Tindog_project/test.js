var n = Math.random();
console.log(n);