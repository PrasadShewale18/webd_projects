// alert("working");
var p1 = Math.floor(6*Math.random()) + 1;
var p2 = Math.floor(6*Math.random()) + 1;

var random_image_1  = "images/" + "dice" + p1 + ".png";
var random_image_2  = "images/" + "dice" + p2 + ".png";
document.querySelectorAll("img")[0].setAttribute("src",random_image_1);
document.querySelectorAll("img")[1].setAttribute("src",random_image_2);

var result;
if(p1 > p2){
    result = "🚩 Play 1 Wins";
}
else if(p1 < p2){
    result = "Play 2 Wins 🚩";
}
else{
    result = "Draw";
}

document.querySelector("h1").innerHTML= result;